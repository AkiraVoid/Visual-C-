﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Capderwolf
{
    public partial class mainWindow : Form
    {
        public mainWindow()
        {
            InitializeComponent();
        }

        private void butChe_Click(object sender, EventArgs e)
        {
            
        }

        private void butRe_Click(object sender, EventArgs e)
        {

        }

        private void ButChe_Click(object sender, EventArgs e)
        {
            RegistryKey student = Registry.LocalMachine.OpenSubKey("SOFTWARE\\TopDomain\\e-learning class standard\\1.00", false);
            
            if (student == null)
            {
                MessageBox.Show("The software have not be installed.");
            }
            else
            {

                string Password = student.GetValue("UninstallPasswd").ToString().Remove(0, 6);
                check.Text = Password;
            }
        }

        private void ButRe_Click(object sender, EventArgs e)
        {

        }
    }
}
