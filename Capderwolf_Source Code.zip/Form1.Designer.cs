﻿namespace Capderwolf
{
    partial class mainWindow
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.check = new System.Windows.Forms.TextBox();
            this.ButChe = new System.Windows.Forms.Button();
            this.labelCheck = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // check
            // 
            this.check.Location = new System.Drawing.Point(54, 55);
            this.check.Name = "check";
            this.check.Size = new System.Drawing.Size(314, 23);
            this.check.TabIndex = 0;
            // 
            // ButChe
            // 
            this.ButChe.Location = new System.Drawing.Point(374, 55);
            this.ButChe.Name = "ButChe";
            this.ButChe.Size = new System.Drawing.Size(75, 23);
            this.ButChe.TabIndex = 2;
            this.ButChe.Text = "Check";
            this.ButChe.UseVisualStyleBackColor = true;
            this.ButChe.Click += new System.EventHandler(this.ButChe_Click);
            // 
            // labelCheck
            // 
            this.labelCheck.AutoSize = true;
            this.labelCheck.Location = new System.Drawing.Point(51, 35);
            this.labelCheck.Name = "labelCheck";
            this.labelCheck.Size = new System.Drawing.Size(45, 17);
            this.labelCheck.TabIndex = 4;
            this.labelCheck.Text = "Check:";
            // 
            // mainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(502, 131);
            this.Controls.Add(this.labelCheck);
            this.Controls.Add(this.ButChe);
            this.Controls.Add(this.check);
            this.Font = new System.Drawing.Font("微软雅黑 Light", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "mainWindow";
            this.Text = "Domain Password Check";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox check;
        private System.Windows.Forms.Button ButChe;
        private System.Windows.Forms.Label labelCheck;
    }
}

